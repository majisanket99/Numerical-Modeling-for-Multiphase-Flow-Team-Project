GFORTRAN module version '10' created from module_globalvariables.F90
MD5:5c379f3bd8e004c51d368fedc0b4888d -- If you edit this, you'll get what you deserve.

(() () () () () () () () () () () () () () () () () () () () () () () ()
() () ())

()

()

()

()

()

(2 'dt' 'module_globalvariables' '' 1 ((VARIABLE UNKNOWN-INTENT
UNKNOWN-PROC UNKNOWN IMPLICIT-SAVE 0 0) (REAL 4 0 0 0 REAL ()) 0 0 () ()
0 () () () 0 0)
3 'dummy' 'module_globalvariables' '' 1 ((PROCEDURE UNKNOWN-INTENT
MODULE-PROC DECL UNKNOWN 0 0 SUBROUTINE IMPLICIT_PURE) (UNKNOWN 0 0 0 0
UNKNOWN ()) 0 0 () () 0 () () () 0 0)
4 'exit_time_loop' 'module_globalvariables' '' 1 ((VARIABLE
UNKNOWN-INTENT UNKNOWN-PROC UNKNOWN IMPLICIT-SAVE 0 0) (LOGICAL 4 0 0 0
LOGICAL ()) 0 0 () () 0 () () () 0 0)
5 'module_globalvariables' 'module_globalvariables' '' 1 ((MODULE
UNKNOWN-INTENT UNKNOWN-PROC UNKNOWN UNKNOWN 0 0) (UNKNOWN 0 0 0 0
UNKNOWN ()) 0 0 () () 0 () () () 0 0)
6 'n_steps' 'module_globalvariables' '' 1 ((VARIABLE UNKNOWN-INTENT
UNKNOWN-PROC UNKNOWN IMPLICIT-SAVE 0 0) (INTEGER 4 0 0 0 INTEGER ()) 0 0
() () 0 () () () 0 0)
7 'nt' 'module_globalvariables' '' 1 ((VARIABLE UNKNOWN-INTENT
UNKNOWN-PROC UNKNOWN IMPLICIT-SAVE 0 0) (INTEGER 4 0 0 0 INTEGER ()) 0 0
() () 0 () () () 0 0)
8 'nt_out' 'module_globalvariables' '' 1 ((VARIABLE UNKNOWN-INTENT
UNKNOWN-PROC UNKNOWN IMPLICIT-SAVE 0 0) (INTEGER 4 0 0 0 INTEGER ()) 0 0
() () 0 () () () 0 0)
9 'pi' 'module_globalvariables' '' 1 ((PARAMETER UNKNOWN-INTENT
UNKNOWN-PROC UNKNOWN IMPLICIT-SAVE 0 0) (REAL 4 0 0 0 REAL ()) 0 0 () (
CONSTANT (REAL 4 0 0 0 REAL ()) 0 '0.3243f6c@1') () 0 () () () 0 0)
10 'plotlinen' 'module_globalvariables' '' 1 ((VARIABLE UNKNOWN-INTENT
UNKNOWN-PROC UNKNOWN IMPLICIT-SAVE 0 0) (INTEGER 4 0 0 0 INTEGER ()) 0 0
() () 0 () () () 0 0)
11 'plotlineu' 'module_globalvariables' '' 1 ((VARIABLE UNKNOWN-INTENT
UNKNOWN-PROC UNKNOWN IMPLICIT-SAVE 0 0 ALLOCATABLE DIMENSION) (REAL 4 0
0 0 REAL ()) 0 0 () (2 0 DEFERRED () () () ()) 0 () () () 0 0)
12 'plotlinex' 'module_globalvariables' '' 1 ((VARIABLE UNKNOWN-INTENT
UNKNOWN-PROC UNKNOWN IMPLICIT-SAVE 0 0 ALLOCATABLE DIMENSION) (REAL 4 0
0 0 REAL ()) 0 0 () (2 0 DEFERRED () () () ()) 0 () () () 0 0)
13 'small' 'module_globalvariables' '' 1 ((PARAMETER UNKNOWN-INTENT
UNKNOWN-PROC UNKNOWN IMPLICIT-SAVE 0 0) (REAL 4 0 0 0 REAL ()) 0 0 () (
CONSTANT (REAL 4 0 0 0 REAL ()) 0 '0.1197998@-9') () 0 () () () 0 0)
14 't' 'module_globalvariables' '' 1 ((VARIABLE UNKNOWN-INTENT
UNKNOWN-PROC UNKNOWN IMPLICIT-SAVE 0 0) (REAL 4 0 0 0 REAL ()) 0 0 () ()
0 () () () 0 0)
15 't_end' 'module_globalvariables' '' 1 ((VARIABLE UNKNOWN-INTENT
UNKNOWN-PROC UNKNOWN IMPLICIT-SAVE 0 0) (REAL 4 0 0 0 REAL ()) 0 0 () ()
0 () () () 0 0)
)

('dt' 0 2 'dummy' 0 3 'exit_time_loop' 0 4 'module_globalvariables' 0 5
'n_steps' 0 6 'nt' 0 7 'nt_out' 0 8 'pi' 0 9 'plotlinen' 0 10 'plotlineu'
0 11 'plotlinex' 0 12 'small' 0 13 't' 0 14 't_end' 0 15)
